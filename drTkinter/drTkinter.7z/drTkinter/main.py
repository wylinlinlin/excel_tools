import os
from PIL import Image

import numpy as np
import pandas as pd

import customtkinter


class App(customtkinter.CTk):
    def __init__(self):
        super().__init__()

        self.title("DR tools")
        self.geometry("700x450")

        # set grid layout 1x2
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        # load images with light and dark mode image
        image_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "test_images")
        self.logo_image = customtkinter.CTkImage(Image.open(os.path.join(image_path, "excel.png")),
                                                 size=(26, 26))
        self.image_icon_image = customtkinter.CTkImage(Image.open(os.path.join(image_path, "export.png")),
                                                       size=(20, 20))
        self.home_image = customtkinter.CTkImage(light_image=Image.open(os.path.join(image_path, "home_dark.png")),
                                                 dark_image=Image.open(os.path.join(image_path, "home_light.png")),
                                                 size=(20, 20))
        # self.chat_image = customtkinter.CTkImage(light_image=Image.open(os.path.join(image_path, "chat_dark.png")),
        #                                          dark_image=Image.open(os.path.join(image_path, "chat_light.png")),
        #                                          size=(20, 20))
        # self.add_user_image = customtkinter.CTkImage(
        #     light_image=Image.open(os.path.join(image_path, "add_user_dark.png")),
        #     dark_image=Image.open(os.path.join(image_path, "add_user_light.png")), size=(20, 20))

        # create navigation frame
        self.navigation_frame = customtkinter.CTkFrame(self, corner_radius=0)
        self.navigation_frame.grid(row=0, column=0, sticky="nsew")
        self.navigation_frame.grid_rowconfigure(4, weight=1)

        self.navigation_frame_label = customtkinter.CTkLabel(self.navigation_frame, text="  DR recon",
                                                             image=self.logo_image,
                                                             compound="left",
                                                             font=customtkinter.CTkFont(size=15, weight="bold"))
        self.navigation_frame_label.grid(row=0, column=0, padx=20, pady=20)

        self.home_button = customtkinter.CTkButton(self.navigation_frame, corner_radius=0, height=40, border_spacing=10,
                                                   text="Home",
                                                   fg_color="transparent", text_color=("gray10", "gray90"),
                                                   hover_color=("gray70", "gray30"),
                                                   image=self.home_image, anchor="w", command=self.home_button_event)
        self.home_button.grid(row=1, column=0, sticky="ew")

        # self.frame_2_button = customtkinter.CTkButton(self.navigation_frame, corner_radius=0, height=40,
        #                                               border_spacing=10, text="Frame 2",
        #                                               fg_color="transparent", text_color=("gray10", "gray90"),
        #                                               hover_color=("gray70", "gray30"),
        #                                               image=self.chat_image, anchor="w",
        #                                               command=self.frame_2_button_event)
        # self.frame_2_button.grid(row=2, column=0, sticky="ew")
        #
        # self.frame_3_button = customtkinter.CTkButton(self.navigation_frame, corner_radius=0, height=40,
        #                                               border_spacing=10, text="Frame 3",
        #                                               fg_color="transparent", text_color=("gray10", "gray90"),
        #                                               hover_color=("gray70", "gray30"),
        #                                               image=self.add_user_image, anchor="w",
        #                                               command=self.frame_3_button_event)
        # self.frame_3_button.grid(row=3, column=0, sticky="ew")

        self.appearance_mode_menu = customtkinter.CTkOptionMenu(
            self.navigation_frame, values=["Light", "Dark", "System"],
            command=self.change_appearance_mode_event)
        self.appearance_mode_menu.grid(row=6, column=0, padx=20, pady=20, sticky="s")

        # create home frame
        self.home_frame = customtkinter.CTkFrame(self, corner_radius=0, fg_color="transparent")
        self.home_frame.grid_columnconfigure(0, weight=1)

        self.home_frame_button_1 = customtkinter.CTkButton(
            self.home_frame, text="Open GL", image=self.image_icon_image,
            command=self.open_gl)
        self.home_frame_button_1.grid(row=1, column=1, padx=20, pady=10)
        self.home_frame_button_2 = customtkinter.CTkButton(
            self.home_frame, text="Open TB", image=self.image_icon_image, compound="left",
            command=self.open_tb)
        self.home_frame_button_2.grid(row=2, column=1, padx=20, pady=10)
        self.home_frame_button_3 = customtkinter.CTkButton(
            self.home_frame, text="Save File", image=self.image_icon_image, compound="left",
            command=self.save_file)
        self.home_frame_button_3.grid(row=3, column=1, padx=20, pady=10)
        self.home_frame_button_4 = customtkinter.CTkButton(
            self.home_frame, text="Run", image=self.image_icon_image, compound="left",
            command=self.run)
        self.home_frame_button_4.grid(row=4, column=1, padx=20, pady=10)

        self.label = customtkinter.StringVar()
        self.label.set("")
        self.label_gl = customtkinter.CTkLabel(self.home_frame, textvariable=self.label)
        self.label_gl.grid(row=1, column=0, padx=10, pady=10)
        # self.label_gl.setvar(self.option.gl)

        self.label2 = customtkinter.StringVar()
        self.label2.set("")
        self.label_tb = customtkinter.CTkLabel(self.home_frame, textvariable=self.label2)
        self.label_tb.grid(row=2, column=0, padx=10, pady=10)

        self.label3 = customtkinter.StringVar()
        self.label3.set("")
        self.label_save = customtkinter.CTkLabel(self.home_frame, textvariable=self.label3)
        self.label_save.grid(row=3, column=0, padx=10, pady=10)

        # create second frame
        self.second_frame = customtkinter.CTkFrame(self, corner_radius=0, fg_color="transparent")

        # create third frame
        self.third_frame = customtkinter.CTkFrame(self, corner_radius=0, fg_color="transparent")

        # select default frame
        self.select_frame_by_name("home")

        # self.dr = DataRecon(self.gl, self.tb, self.save_name)

    def open_gl(self):
        try:
            self.gl = customtkinter.filedialog.askopenfilename()
            self.label.set(self.gl)
        except Exception as e:
            print(e)

    def open_tb(self):
        try:
            self.tb = customtkinter.filedialog.askopenfilename()
            self.label2.set(self.tb)
        except Exception as e:
            print(e)

    def save_file(self):
        files = [("Excel files", "*.xlsx"), ('All Files', '*.*')]
        try:
            self.save = customtkinter.filedialog.asksaveasfilename(filetypes=files, initialfile="pt.xlsx")
            basename = os.path.basename(self.save)
            if basename.endswith(".xlsx"):
                self.label3.set(self.save)
                self.save_name = self.save
            else:
                self.label3.set(self.save + ".xlsx")
                self.save_name = self.save + ".xlsx"
        except Exception as e:
            print(e)

    def select_frame_by_name(self, name):
        # set button color for selected button
        self.home_button.configure(fg_color=("gray75", "gray25") if name == "home" else "transparent")
        # self.frame_2_button.configure(fg_color=("gray75", "gray25") if name == "frame_2" else "transparent")
        # self.frame_3_button.configure(fg_color=("gray75", "gray25") if name == "frame_3" else "transparent")

        # show selected frame
        if name == "home":
            self.home_frame.grid(row=0, column=1, sticky="nsew")
        else:
            self.home_frame.grid_forget()
        if name == "frame_2":
            self.second_frame.grid(row=0, column=1, sticky="nsew")
        else:
            self.second_frame.grid_forget()
        if name == "frame_3":
            self.third_frame.grid(row=0, column=1, sticky="nsew")
        else:
            self.third_frame.grid_forget()

    def home_button_event(self):
        self.select_frame_by_name("home")

    def frame_2_button_event(self):
        self.select_frame_by_name("frame_2")

    def frame_3_button_event(self):
        self.select_frame_by_name("frame_3")

    def change_appearance_mode_event(self, new_appearance_mode):
        customtkinter.set_appearance_mode(new_appearance_mode)

    def run(self):
        try:
            dr = DataRecon(
                path_gl=self.gl,
                path_tb=self.tb,
                save_name=self.save_name
            )
        except Exception as e:
            print(e)


class DataRecon:
    def __init__(self, path_gl, path_tb, save_name) -> None:
        self.path_gl = path_gl
        self.path_tb = path_tb
        self.save_name = save_name
        # self.save_path = save_path
        self.pivot_data()

    def read_file(self, file_path):
        """ 读取文件 """
        try:
            data = pd.read_excel(file_path, dtype=object)
        except:
            data = pd.read_csv(file_path, dtype=object)
        return data

    def handle_gl(self):
        try:
            # read GL
            data = self.read_file(self.path_gl)
            # 将dr与cr转为float
            data["借方发生额"] = data["借方发生额"].astype(float)
            data["贷方发生额"] = data["贷方发生额"].astype(float)
            # add column account, opening, closing
            data["account"] = data["被审计单位"] + "_" + data["科目编号"]
            data["opening"] = None
            data["closing"] = None
            # get amount for gl
            data["amount"] = data["借方发生额"] - data["贷方发生额"]
            print(f"read GL -> {os.path.basename(self.path_gl)} successfully.")
            return data.loc[:, ["account", "opening", "closing", "amount"]]
        except Exception as e:
            print(e)

    def handle_tb(self):
        try:
            # read TB
            data = self.read_file(self.path_tb)
            # 将opening与closing转为float
            data["期初数"] = data["期初数"].astype(float)
            data["期末数"] = data["期末数"].astype(float)
            # get account, opening, closing, amount
            data["account"] = data["被审计单位"] + "_" + data["科目编号"]
            data["opening"] = data.apply(lambda x: x["期初数"] if x["借贷方向"] == "借" else x["期初数"] * -1, axis=1)
            data["closing"] = data.apply(lambda y: y["期末数"] if y["借贷方向"] == "借" else y["期末数"] * -1, axis=1)
            data["amount"] = None
            print(f"read TB -> {os.path.basename(self.path_tb)} successfully.")
            return data.loc[:, ["account", "opening", "closing", "amount"]]
        except Exception as e:
            print(e)

    def merge_data(self):
        """ 合并GL和TB """
        gl = self.handle_gl()
        tb = self.handle_tb()
        try:
            # merge gl and tb
            rt = pd.concat([gl, tb], axis=0, ignore_index=False, sort=False)
            rt["opening"] = rt["opening"].astype(float)
            rt["closing"] = rt["closing"].astype(float)
            rt["amount"] = rt["amount"].astype(float)
            print("merge completed.")
            return rt
        except Exception as e:
            print(e)

    def pivot_data(self) -> None:
        rt = self.merge_data()
        # pivot
        pt = pd.pivot_table(rt, index=['account'], values=['opening', 'closing', 'amount'], aggfunc=np.sum)
        print(f"pivot completed.")
        # insert column
        pt.insert(loc=0, column="account", value=pt.index)
        # reset index
        pt.reset_index(drop=True, inplace=True)
        # calculate diff
        pt["diff"] = pt["opening"] - pt["closing"] + pt["amount"]
        try:
            pt.to_excel(f"{self.save_name}.xlsx", index=False, encoding="gbk")
            print(f"save path -> '{self.save_name}.xlsx'")
        except Exception as e:
            print(e)


if __name__ == "__main__":
    app = App()
    app.mainloop()
